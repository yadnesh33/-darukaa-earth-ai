import json, re
from pathlib import Path

STOP=set("the a an and or of to in on for with is are can from that this it as by be".split())

class KnowledgeRetriever:
    def __init__(self, knowledge_path: Path):
        self.items=json.loads(knowledge_path.read_text(encoding="utf-8"))
        self.docs=[]
        for item in self.items:
            text=(item["title"]+" "+item["content"]+" "+" ".join(item.get("tags",[]))).lower()
            tokens={t for t in re.findall(r"[a-z0-9]+",text) if len(t)>2 and t not in STOP}
            self.docs.append(tokens)

    def search(self, query, top_k=5):
        q={t for t in re.findall(r"[a-z0-9]+",query.lower()) if len(t)>2 and t not in STOP}
        ranked=[]
        for item,tokens in zip(self.items,self.docs):
            overlap=len(q & tokens)
            ranked.append((overlap,item))
        ranked.sort(key=lambda x:x[0],reverse=True)
        return [item for score,item in ranked[:top_k] if score>0] or self.items[:top_k]
