from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from pathlib import Path
import json

from app.rag import KnowledgeRetriever
from app.reasoning import build_analysis

BASE = Path(__file__).resolve().parent.parent
knowledge_path = BASE / "data" / "knowledge.json"

app = FastAPI(title="Darukaa.Earth AI Biodiversity Intelligence", version="1.0.0")
retriever = KnowledgeRetriever(knowledge_path)

class EnvironmentalInput(BaseModel):
    soil_organic_carbon: float | None = Field(None, ge=0)
    soil_ph: float | None = Field(None, ge=0, le=14)
    soil_moisture: float | None = Field(None, ge=0)
    rainfall: str | None = None
    temperature: float | None = None
    land_use: str | None = None
    biodiversity: str | None = None
    pollution: str | None = None
    deforestation: str | None = None
    region: str | None = None
    query: str | None = None
    conversation_id: str = "default"

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "darukaa-earth"}

@app.post("/api/analyze")
def analyze(data: EnvironmentalInput):
    payload = data.model_dump()
    missing = []
    for field in ["soil_organic_carbon", "rainfall", "land_use"]:
        if payload.get(field) is None:
            missing.append(field)

    if len(missing) >= 2 and not data.query:
        return {
            "type": "clarification",
            "message": "I need a little more environmental context before making a grounded recommendation.",
            "missing_fields": missing,
            "questions": [
                "What is the soil organic carbon percentage?",
                "What is the rainfall pattern?",
                "What is the current land-use or crop type?"
            ][:len(missing)]
        }

    query = data.query or json.dumps(payload)
    evidence = retriever.search(query, top_k=4)
    result = build_analysis(payload, evidence)
    result["retrieved_evidence"] = evidence
    return result

app.mount("/", StaticFiles(directory=str(BASE / "frontend"), html=True), name="frontend")
