def build_analysis(x,evidence):
    carbon=x.get("soil_organic_carbon")
    rainfall=str(x.get("rainfall") or "").lower()
    land=str(x.get("land_use") or "").lower()
    biodiversity=str(x.get("biodiversity") or "").lower()
    region=str(x.get("region") or "").lower()
    pollution=str(x.get("pollution") or "").lower()

    factors=[]; actions=[]

    if carbon is not None:
        if carbon < 1:
            factors.append(f"Soil organic carbon is {carbon}%, which the system flags as a low-carbon condition for this prototype.")
            actions.append(("Cover-crop or residue-retention rotation","More organic inputs can support soil structure, water retention and biological activity.","Soil organic carbon; soil moisture; soil biological activity","medium"))
        else:
            factors.append(f"Soil organic carbon is {carbon}%; retain organic inputs and monitor the trend rather than relying on a single reading.")

    dry=("low" in rainfall or "semi-arid" in region or "dry" in rainfall)
    if dry:
        factors.append("Low/dry rainfall context raises water-availability pressure, so soil and habitat recommendations should also consider moisture.")
        actions.append(("Pair soil cover with water-retention measures","Keeping soil covered and improving infiltration/retention can reduce exposure to water stress and support soil organisms.","Soil moisture; plant survival; soil biological activity","short to medium"))

    if "mono" in land or "single crop" in land:
        factors.append("A monoculture signal indicates limited crop diversity, which can also limit habitat variety.")
        actions.append(("Introduce compatible intercropping or habitat strips","Diversification can create additional resources and niches while changing the relationship between productive land and habitat.","Habitat diversity; species richness; soil health","medium to long"))

    if "declin" in biodiversity:
        factors.append("The biodiversity input indicates a declining trend; habitat structure and connectivity should therefore be assessed.")
        actions.append(("Retain or restore connected habitat patches","Reducing fragmentation pressure can improve habitat continuity and provide refuges/resources for species.","Species richness; habitat diversity; connectivity","medium to long"))

    if pollution in {"high","severe"}:
        factors.append("High pollution is an additional human-pressure variable and should be investigated alongside land and biodiversity data.")
        actions.append(("Map and reduce the dominant pollution source","Targeting the actual source avoids treating a complex pollution problem with a generic biodiversity intervention.","Pollution load; species survival; habitat quality","short to medium"))

    if not actions:
        actions.append(("Establish a multi-metric baseline and monitoring plan","Tracking soil, climate, land-use and biodiversity together makes changes easier to interpret and validate.","Soil health; water availability; biodiversity","short"))

    recs=[]
    for name,why,metrics,horizon in actions:
        recs.append({
            "recommendation":name,"why":why,"metrics":metrics.split("; "),
            "time_horizon":horizon+" term",
            "evidence":[{"title":e["title"],"source":e["source"],"url":e["url"]} for e in evidence]
        })
    return {
      "type":"analysis",
      "summary":"The system combined soil, climate, land-use and biodiversity signals where available, then grounded the response in retrieved environmental sources.",
      "reasoning_factors":factors,
      "recommendations":recs,
      "confidence":"medium — validate site-specific conditions before implementation",
      "input_metrics_used":[k for k,v in x.items() if v is not None and k not in {"query","conversation_id"}]
    }
