# Darukaa.Earth — AI Biodiversity Intelligence

A working reference implementation for the Darukaa.Earth AI Biodiversity Intelligence Chatbot Challenge.

## Stack
- Python 3.11+
- FastAPI
- ChromaDB
- Sentence Transformers
- SQLite
- Vanilla HTML/CSS/JS frontend

## Features
- Environmental metric input
- Clarifying questions for missing data
- Multi-metric reasoning across soil, rainfall, land use and biodiversity
- Local RAG knowledge layer
- Evidence-backed recommendations
- Structured JSON API
- Conversation memory
- Scientific source references

## Run locally

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
python -m uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000

## API
POST `/api/analyze`

Example:
```json
{
  "soil_organic_carbon": 0.3,
  "soil_ph": 6.5,
  "soil_moisture": 18,
  "rainfall": "low",
  "temperature": 31,
  "land_use": "monoculture wheat",
  "biodiversity": "declining",
  "pollution": "low",
  "deforestation": "low",
  "region": "semi-arid"
}
```

## Knowledge grounding
The prototype includes a small curated knowledge file in `data/knowledge.json`. For a production/hackathon submission, expand this with primary research papers, FAO/IPCC reports and environmental datasets, preserving source metadata and citations.

## CI/CD
A GitHub Actions workflow is included under `.github/workflows/ci.yml`.

## Demo flow
Click **Load demo** on the dashboard to populate the challenge-style semi-arid monoculture example, then run analysis.
