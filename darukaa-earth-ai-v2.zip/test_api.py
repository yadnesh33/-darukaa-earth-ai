from app.reasoning import build_analysis

def test_reasoning_uses_multiple_variables():
    r=build_analysis({'soil_organic_carbon':.3,'rainfall':'low','land_use':'monoculture','biodiversity':'declining'}, [])
    assert len(r['recommendations']) >= 2
    assert len(r['input_metrics_used']) == 4
